
/*Array de frutas*/ 
const frutas = [
  { id: 1, nombre: 'Manzana', precio: 2000 },
  { id: 2, nombre: 'Banana', precio: 3000 },
  { id: 3, nombre: 'Naranja', precio: 1500 },
  { id: 4, nombre: 'Uva', precio: 2900 },
  { id: 5, nombre: 'Pera', precio: 4000 },
  { id: 6, nombre: 'Kiwi', precio: 5000 },
];

/*Elementos del DOM */
const frutasDiv = document.getElementById('frutas');
const listaCarrito = document.getElementById('lista-carrito');
const totalCarrito = document.getElementById('total');
const botonVaciarCarrito = document.getElementById('vaciar-carrito');


let carrito = [];

/*Funcion para cargar el carrito desde LocalStorage*/
function cargarCarrito() {
  const carritoGuardado = JSON.parse(localStorage.getItem('carrito'));
  if (carritoGuardado) {
    carrito = carritoGuardado;
  }
  actualizarCarrito();
}

/* Funcion para guardar el carrito en LocalStorage*/
function guardarCarrito() {
  localStorage.setItem('carrito', JSON.stringify(carrito));
}

/*Funcion para renderizar las frutas */
function renderizarFrutas() {
  frutas.forEach(fruta => {
    const div = document.createElement('div');
    div.classList.add('producto');
    div.innerHTML = `
      <h3>${fruta.nombre}</h3>
      <p>Precio: $${fruta.precio.toFixed(2)}</p>
      <button data-id="${fruta.id}">Añadir al Carrito</button>
    `;
    frutasDiv.appendChild(div);
  });
}

/* Función para actualizar el carrito en el DOM*/
function actualizarCarrito() {

listaCarrito.innerHTML = '';

/*Calcular el total */
let total = 0;

/* Recorrer el carrito y agregar las frutas al DOM*/
carrito.forEach(fruta => {
  const li = document.createElement('li');
  li.innerHTML = `
    ${fruta.nombre} - $${fruta.precio.toFixed(2)}
    <button class="eliminar" data-id="${fruta.id}">Eliminar</button>
  `;
  listaCarrito.appendChild(li);
  total += fruta.precio;
});

/* Actualizar el total en el DOM*/
totalCarrito.textContent = `Total: $${total.toFixed(2)}`;


botonVaciarCarrito.disabled = carrito.length === 0;
}

/* Función para añadir una fruta al carrito*/
function añadirAlCarrito(id) {
  const fruta = frutas.find(f => f.id === id);
  if (fruta) {
    carrito.push(fruta);
    guardarCarrito();
    actualizarCarrito();
  }
}

/* Función para eliminar una fruta del carrito*/
function eliminarDelCarrito(id) {
  carrito = carrito.filter(f => f.id !== id);
  guardarCarrito();
  actualizarCarrito();
}

/* Función para vaciar el carrito*/
function vaciarCarrito() {
  carrito = [];
  guardarCarrito();
  actualizarCarrito();
}

/*EventListeners*/
frutasDiv.addEventListener('click', (e) => {
  if (e.target.tagName === 'BUTTON') {
    const id = parseInt(e.target.getAttribute('data-id'));
    añadirAlCarrito(id);
  }
});

listaCarrito.addEventListener('click', (e) => {
  if (e.target.classList.contains('eliminar')) {
    const id = parseInt(e.target.getAttribute('data-id'));
    eliminarDelCarrito(id);
  }
});

botonVaciarCarrito.addEventListener('click', vaciarCarrito);


cargarCarrito();  /*Cargar el carrito desde LocalStorage cuando inicie la pagina*/
renderizarFrutas();  
