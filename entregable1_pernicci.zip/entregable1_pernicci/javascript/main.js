/*Listado de Frutas */
const frutas = ["manzana", "banana", "naranja", "uva", "pera", "kiwi", "sandía", "fresa", "mango", "durazno"];

/*Función para buscar frutas */
function buscarFruta() {
const frutaBuscada = prompt("Ingresa el nombre de la fruta que estás buscando:").toLowerCase();


/* Verificar si la fruta ingresada existe en la lista*/ 
 if (frutas.includes(frutaBuscada)) {
    console.log(`¡La fruta ${frutaBuscada} está disponible!`);
  } else {
    console.log(`Lo siento, la fruta ${frutaBuscada} no está en el inventario.`);
    
    /* Función para encargar la fruta*/
    const encargar = prompt(`¿Te gustaría encargar la fruta ${frutaBuscada}? (sí/no)`).toLowerCase();
    if (encargar === "sí" || encargar === "si") {
    /* Llamamos a la función para encargar la fruta*/
    encargarFruta(frutaBuscada);  // Pasamos el nombre de la fruta a encargar
    } else {
      console.log("No se ha encargado ninguna fruta.");
    }
}
}
function encargarFruta(fruta){
    frutas.push(fruta);
    console.log(`La fruta ${fruta} ha sido encargada y ahora se mostrara en el inventario.`)
}

function menuFrutas() {
    let opcion;
    do {
    /*Pedimos que se busque una fruta */
    opcion = prompt(
      "Bienvenido al simulador de búsqueda de frutas\n" +
      "1. Buscar fruta\n" +
      "2. Salir\n" +
      "Seleccione una opción (1 o 2):"
    );
  
    switch (opcion) {
        case "1":
        /* Función para buscar la fruta*/
        buscarFruta();
        break;
        case "2":
        console.log("Gracias por usar el simulador de frutas. ¡Hasta luego!");
        break;
        default:
        console.log("Opción no válida, por favor intente de nuevo.");
    }
    } while (opcion !== "2");
}

menuFrutas();
